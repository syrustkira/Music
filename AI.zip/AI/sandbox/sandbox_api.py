# filename: sandbox/sandbox_api.py
from flask import Flask, request, jsonify
import importlib.util
import os
import inspect

app = Flask(__name__)

PLUGIN_DIR = "/plugins"

@app.route("/plugins")
def list_plugins():
    """Lists available plugins and their functions."""
    plugins_info = {}
    for filename in os.listdir(PLUGIN_DIR):
        if filename.endswith(".py"):
            plugin_name = filename[:-3]
            plugin_path = os.path.join(PLUGIN_DIR, filename)
            try:
                spec = importlib.util.spec_from_file_location(plugin_name, plugin_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                functions = {}
                for name, member in inspect.getmembers(module, inspect.isfunction):
                    if not name.startswith('_'): # Exclude private functions
                        sig = inspect.signature(member)
                        functions[name] = str(sig)
                plugins_info[plugin_name] = functions
            except Exception as e:
                print(f"Error loading plugin {plugin_name}: {e}")
    return jsonify({"plugins": plugins_info})

@app.route("/execute", methods=["POST"])
def execute_plugin():
    data = request.json
    plugin_name = data.get("plugin_name")
    function_name = data.get("function_name")
    args = data.get("args", [])
    
    plugin_path = os.path.join("/plugins", f"{plugin_name}.py")
    
    if not os.path.exists(plugin_path):
        return jsonify({"error": "Plugin not found."}), 404

    try:
        spec = importlib.util.spec_from_file_location(plugin_name, plugin_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        func = getattr(module, function_name)
        result = func(*args)
        
        return jsonify({"result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
