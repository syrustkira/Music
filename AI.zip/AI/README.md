# AI Companion for Raspberry Pi

This project implements an autonomous, local-first AI companion on a Raspberry Pi 4. It is designed to be extensible, self-optimizing, and capable of working completely offline.

## Architecture

The system uses a modular, agent-based approach with the following key components:

*   **Core Agent:** Orchestrates tasks, leveraging a small, quantized LLM (TinyLlama via Ollama) for reasoning and task planning.
*   **Tiered Memory:** Utilizes ChromaDB for long-term memory (Retrieval-Augmented Generation) and in-memory buffers for short-term context.
*   **Plugin Sandboxing:** Runs plugins in isolated Docker containers to ensure security and prevent resource conflicts.
*   **FastAPI Backend:** Exposes a web API for user interaction and system monitoring.
*   **Web Client:** A simple HTML/CSS/JS interface for demonstration purposes.
*   **Autonomous Optimization:** A background script analyzes performance metrics and provides suggestions for improving efficiency.

## Setup

### Prerequisites

*   A Raspberry Pi 4 (or newer) with a 64-bit OS (e.g., Raspberry Pi OS Lite 64-bit).
*   Docker and Docker Compose installed on the Raspberry Pi.
*   A fast boot drive (SSD is highly recommended) for optimal performance.

### Instructions

1.  **Clone the repository:**
    ```bash
    git clone [repository-url]
    cd ai-companion
    ```

2.  **Configure environment variables:**
    Create a `.env` file in the root directory and configure it as needed.

3.  **Start the services:**
    ```bash
    docker-compose up -d
    ```
    This will build the necessary Docker images and start all services, including Ollama, ChromaDB, and the FastAPI API.

4.  **Wait for Ollama model download:**
    The `tinyllama` model will be downloaded automatically when the `ollama` container starts. This may take some time depending on your internet speed.

5.  **Access the web interface:**
    Open your web browser and navigate to `http://<your_pi_ip>:8008` to access the AI companion's web UI.

## Usage

*   **Web Interface:** Use the simple web client to interact with the AI.
*   **API:** Make `POST` requests to `/process_intent/` with a JSON payload of `{"intent": "Your query"}`.
*   **Plugins:** Add new plugins by creating a subdirectory under the `plugins` directory and defining a `plugin.py` and `Dockerfile`.

## Optimization

To maximize performance, consider the following:
*   **Review `performance.log`:** Regularly check this file for insights on slow tasks.
*   **Run the optimizer script:**
    ```bash
    docker-compose run --rm api python scripts/optimize.py
    ```
*   **Offload Intensive Tasks:** If the optimizer suggests offloading a task, modify the core agent logic or a specific plugin to use a cloud-based service when an internet connection is available.
