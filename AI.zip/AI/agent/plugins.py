import docker
import json
import logging
import os
import threading
from typing import Dict, Any, List

class PluginManager:
    def __init__(self):
        self.plugins = {}
        self.client = docker.from_env()
        self.lock = threading.Lock()
        
    def load_all_plugins(self):
        plugins_dir = "plugins"
        if not os.path.exists(plugins_dir):
            return
        
        for plugin_name in os.listdir(plugins_dir):
            plugin_path = os.path.join(plugins_dir, plugin_name)
            if os.path.isdir(plugin_path) and os.path.exists(os.path.join(plugin_path, "Dockerfile")):
                try:
                    self.client.images.build(path=plugin_path, tag=f"ai-plugin-{plugin_name}")
                    self.plugins[plugin_name] = f"ai-plugin-{plugin_name}"
                    logging.info(f"Plugin '{plugin_name}' image built.")
                except docker.errors.BuildError as e:
                    logging.error(f"Failed to build plugin image for '{plugin_name}': {e}")
        
    def get_available_plugins(self) -> List[str]:
        return list(self.plugins.keys())

    def execute_plugin(self, plugin_name: str, args: Dict) -> str:
        image_tag = self.plugins.get(plugin_name)
        if not image_tag:
            return f"Error: Plugin '{plugin_name}' not found."

        with self.lock:
            try:
                container = self.client.containers.run(
                    image_tag,
                    command=['python', 'plugin.py', json.dumps(args)],
                    remove=True,
                    detach=False,
                    network="none" if plugin_name != "iot_control" else "host"
                )
                return container.decode('utf-8').strip()
            except docker.errors.ContainerError as e:
                logging.error(f"Plugin '{plugin_name}' failed with an error: {e.stderr.decode('utf-8')}")
                return f"Plugin '{plugin_name}' execution failed: {e.stderr.decode('utf-8')}"
            except Exception as e:
                logging.error(f"Unexpected error during plugin execution: {e}")
                return "An unexpected error occurred."
