import chromadb
from sentence_transformers import SentenceTransformer
import os
import uuid
from typing import List, Dict

class LongTermMemory:
    def __init__(self):
        self.chroma_host = os.getenv("CHROMA_HOST", "http://chroma:8000")
        self.client = chromadb.HttpClient(host=self.chroma_host)
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        self.collection = self.client.get_or_create_collection(name="long_term_memory")
    
    def add_to_memory(self, text: str, metadata: Dict = {}):
        embedding = self.embedding_model.encode(text).tolist()
        self.collection.add(
            documents=[text],
            embeddings=[embedding],
            metadatas=[metadata],
            ids=[str(uuid.uuid4())]
        )
    
    def retrieve_context(self, query: str, n_results: int = 3) -> List[str]:
        query_embedding = self.embedding_model.encode(query).tolist()
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results
        )
        return results.get('documents', [])
