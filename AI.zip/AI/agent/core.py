import json
import logging
import requests
import os
import subprocess
import time
from typing import Dict, Any, List
from .memory import LongTermMemory
from .plugins import PluginManager

class AI_Core:
    def __init__(self):
        self.ollama_host = os.getenv("OLLAMA_HOST", "http://ollama:11434")
        self.memory = LongTermMemory()
        self.plugin_manager = PluginManager()
        self.plugin_manager.load_all_plugins()

    def get_ollama_completion(self, model: str, prompt: str) -> str:
        try:
            response = requests.post(
                f"{self.ollama_host}/api/generate",
                json={"model": model, "prompt": prompt, "stream": False},
                headers={'Content-Type': 'application/json'},
                timeout=60
            )
            response.raise_for_status()
            return response.json().get("response", "").strip()
        except requests.exceptions.RequestException as e:
            logging.error(f"Error communicating with Ollama: {e}")
            return "Error: Could not reach the local LLM service."

    def process_intent(self, intent: str) -> str:
        start_time = time.time()
        
        context_docs = self.memory.retrieve_context(intent)
        context_str = "\n".join(context_docs)
        
        planning_prompt = f"""
        Context from long-term memory:
        {context_str}

        Plugins available: {self.plugin_manager.get_available_plugins()}
        User intent: "{intent}"

        Based on the context and plugins, generate a JSON plan. If no plugin is needed, set "tool" to "none" and "output" to the intended response.
        Example plan: {{"tool": "web_search", "args": {{"query": "best pizza nearby"}}}}
        """
        plan_response = self.get_ollama_completion("tinyllama", planning_prompt)
        
        try:
            plan = json.loads(plan_response)
            tool = plan.get("tool")
            args = plan.get("args", {})
            
            if tool == "none":
                result = plan.get("output", "No specific tool required.")
            else:
                result = self.plugin_manager.execute_plugin(tool, args)
            
            self.memory.add_to_memory(f"User: {intent}\nAgent: {result}")
            
            duration = time.time() - start_time
            with open("performance.log", "a") as f:
                log_entry = {"timestamp": time.time(), "task": tool, "duration": duration, "success": True}
                f.write(json.dumps(log_entry) + "\n")
                
            return result
            
        except (json.JSONDecodeError, KeyError) as e:
            logging.error(f"Failed to parse or execute plan: {e}. Raw plan: {plan_response}")
            return "Sorry, I encountered an internal error while processing your request."

if __name__ == '__main__':
    core = AI_Core()
    while True:
        user_input = input("User: ")
        if user_input.lower() in ["exit", "quit"]:
            break
        print(f"Agent: {core.process_intent(user_input)}")
