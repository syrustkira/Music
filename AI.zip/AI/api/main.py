from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sys
import os

# Assuming the project structure is flat for simplicity here,
# in a real setup, PYTHONPATH needs to be configured.
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from agent.core import AI_Core

app = FastAPI(title="AI Companion API")
ai_core = AI_Core()

class UserIntent(BaseModel):
    intent: str

@app.post("/process_intent/")
async def process_user_intent(user_intent: UserIntent):
    try:
        response = ai_core.process_intent(user_intent.intent)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
async def get_status():
    return {"status": "ok", "plugins": ai_core.plugin_manager.get_available_plugins()}
