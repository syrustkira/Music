from pydantic import BaseModel

class UserIntent(BaseModel):
    intent: str
