# filename: autogen-core/core.py
"""
Async-first AutoGen core service.
- Async HTTP via httpx.AsyncClient with tenacity retries
- Redis via redis.asyncio (async pubsub + publish)
- Ollama calls wrapped in asyncio.to_thread
- Git plugin updater wrapped in asyncio.to_thread
- Chroma queries executed in thread (client likely sync)
- Plugin tool registration uses a sync httpx.Client wrapper (register_function expects callables)
"""

import asyncio
import json
import logging
import os
import time
import uuid
from functools import partial
from typing import Any, Dict, List, Optional

import git
import httpx
import redis.asyncio as aioredis
import redis
import openai
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, constr
from autogen import ConversableAgent, GroupChat, GroupChatManager, register_function
from autogen.oai.client import OpenAIClient as OAIClient
from chromadb import HttpClient

# -----------------------
# Logging & app
# -----------------------
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("autogen_core")

app = FastAPI()

# -----------------------
# Config & secrets
# -----------------------
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://ollama:11434")
CHROMA_HOST = os.getenv("CHROMA_HOST", "http://chroma:8000")
LLM_OFFLOADER_URL = os.getenv("LLM_OFFLOADER_URL", "http://llm-offloader:8002")
PLUGIN_SANDBOX_URL = os.getenv("PLUGIN_SANDBOX_URL", "http://plugin-sandbox:5000")
ACTIVEPIECES_URL = os.getenv("ACTIVEPIECES_URL", "http://activepieces:3000")
REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
PLUGIN_REPO_URL = os.getenv("PLUGIN_REPO", "https://github.com/yourname/ai-plugins.git")
PLUGIN_DIR = os.getenv("PLUGIN_DIR", "/plugins")

# prefer docker secrets files, fallback to env
def _read_secret(path: Optional[str]) -> Optional[str]:
    if not path:
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    except Exception:
        return None

OPENAI_API_KEY = _read_secret(os.getenv("OPENAI_API_KEY_FILE", "/run/secrets/openai_api_key")) or os.getenv("OPENAI_API_KEY")
ACTIVEPIECES_API_KEY = _read_secret(os.getenv("ACTIVEPIECES_API_KEY_FILE", "/run/secrets/activepieces_api_key")) or os.getenv("ACTIVEPIECES_API_KEY")

if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

# -----------------------
# HTTP clients & retry
# -----------------------
ASYNC_HTTP_TIMEOUT = float(os.getenv("HTTP_TIMEOUT", 10.0))
HTTP_RETRY_ATTEMPTS = int(os.getenv("HTTP_RETRY", 3))

http_async_client = httpx.AsyncClient(timeout=ASYNC_HTTP_TIMEOUT)
# plugin calls registered as tools may be invoked synchronously by autogen internals,
# so keep a sync client for those wrappers.
http_sync_client = httpx.Client(timeout=ASYNC_HTTP_TIMEOUT)

retry_policy = dict(
    stop=stop_after_attempt(HTTP_RETRY_ATTEMPTS),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type(httpx.RequestError),
    reraise=True,
)


@retry(**retry_policy)
async def async_get(url: str, params: dict = None, headers: dict = None) -> httpx.Response:
    return await http_async_client.get(url, params=params, headers=headers)


@retry(**retry_policy)
async def async_post(url: str, json_body: dict = None, headers: dict = None) -> httpx.Response:
    return await http_async_client.post(url, json=json_body, headers=headers)


def sync_post(url: str, json_body: dict = None, headers: dict = None) -> httpx.Response:
    """Sync post with simple retry (tenacity not applied to avoid complexity here)."""
    backoff = 1.0
    for attempt in range(HTTP_RETRY_ATTEMPTS):
        try:
            r = http_sync_client.post(url, json=json_body, headers=headers)
            r.raise_for_status()
            return r
        except Exception as e:
            logger.debug("sync_post attempt %s failed: %s", attempt + 1, e)
            time.sleep(backoff)
            backoff = min(backoff * 2, 10.0)
    raise RuntimeError(f"sync_post failed for {url}")

# -----------------------
# Redis (async)
# -----------------------
aioredis_client = aioredis.from_url(f"redis://{REDIS_HOST}:{REDIS_PORT}", decode_responses=True)

async def publish_message(channel: str, payload: Dict[str, Any]) -> None:
    try:
        await aioredis_client.publish(channel, json.dumps(payload))
    except Exception:
        logger.exception("Failed to publish message to %s", channel)

# -----------------------
# Chroma (likely sync) - wrap calls in thread
# -----------------------
chroma_client = None
memory_collection = None
try:
    # defensive construction
    try:
        chroma_client = HttpClient(base_url=CHROMA_HOST)
    except TypeError:
        chroma_client = HttpClient(host=CHROMA_HOST, port=8000)
    try:
        memory_collection = chroma_client.get_or_create_collection(name="user_interactions")
    except TypeError:
        memory_collection = chroma_client.get_or_create_collection("user_interactions")
    logger.info("Chroma client initialized")
except Exception:
    logger.warning("Chroma client init failed; memory disabled", exc_info=True)
    chroma_client = None
    memory_collection = None

def _normalize_chroma_docs(results: Any) -> List[str]:
    if not results:
        return []
    if isinstance(results, dict):
        docs = results.get("documents") or []
    else:
        docs = results
    flat: List[str] = []
    for item in docs:
        if isinstance(item, list):
            flat.extend([str(x) for x in item])
        else:
            flat.append(str(item))
    return flat

def get_relevant_memory_sync(user_id: str, query: str, top_k: int = 5) -> List[str]:
    if memory_collection is None:
        return []
    try:
        # embeddings via ollama endpoint (sync HTTP)
        r = http_sync_client.post(f"{OLLAMA_BASE_URL}/api/embeddings", json={"model": "nomic-embed-text", "prompt": query})
        r.raise_for_status()
        payload = r.json()
        embedding = payload.get("embedding") or (payload.get("data", [{}])[0].get("embedding") if isinstance(payload, dict) else None)
        if not embedding:
            return []
        results = memory_collection.query(query_embeddings=[embedding], n_results=top_k, where={"user": user_id})
        return _normalize_chroma_docs(results)
    except Exception:
        logger.exception("get_relevant_memory_sync failed")
        return []

async def get_relevant_memory(user_id: str, query: str, top_k: int = 5) -> List[str]:
    return await asyncio.to_thread(get_relevant_memory_sync, user_id, query, top_k)

# -----------------------
# Ollama (sync client) - wrap in thread to keep async loop free
# -----------------------
try:
    ollama_client = OAIClient(config_list=[{"model": "llama3", "api_key": "ollama", "base_url": OLLAMA_BASE_URL}])
except Exception:
    logger.warning("Failed to init Ollama client", exc_info=True)
    ollama_client = None

async def call_local_llm(prompt: str) -> str:
    if not ollama_client:
        return "Error: local LLM unavailable."
    def _sync():
        try:
            resp = ollama_client.create(messages=[{"role": "user", "content": prompt}])
            # defensive extraction
            if isinstance(resp, dict):
                return resp.get("choices", [{}])[0].get("message", {}).get("content", "") or str(resp)
            if hasattr(resp, "choices"):
                choice = resp.choices[0]
                if hasattr(choice, "message") and hasattr(choice.message, "content"):
                    return choice.message.content
                return getattr(choice, "text", str(choice))
            return str(resp)
        except Exception:
            logger.exception("OLLAMA call failed")
            return "Error: local LLM call failed."
    return await asyncio.to_thread(_sync)

# -----------------------
# Hybrid LLM call (offload async, local in thread)
# -----------------------
async def call_llm(prompt: str) -> str:
    # offload if long and OPENAI API key is available
    if len(prompt.split()) > 100 and OPENAI_API_KEY:
        try:
            resp = await async_post(f"{LLM_OFFLOADER_URL}/offload/", json_body={"prompt": prompt})
            data = resp.json()
            return data.get("response", "") or data.get("text", "")
        except Exception:
            logger.exception("Offloader call failed - falling back to local")
    return await call_local_llm(prompt)

# -----------------------
# ActivePieces trigger (async)
# -----------------------
async def trigger_activepieces_flow(flow_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
    if not ACTIVEPIECES_API_KEY:
        return {"error": "ActivePieces API key not configured."}
    headers = {"Authorization": f"Bearer {ACTIVEPIECES_API_KEY}", "Content-Type": "application/json"}
    try:
        resp = await async_post(f"{ACTIVEPIECES_URL}/runs/{flow_id}", json_body=data, headers=headers)
        return resp.json()
    except Exception:
        logger.exception("ActivePieces trigger failed")
        return {"error": "ActivePieces trigger failed"}

# -----------------------
# Plugin discovery & registration
# -----------------------
async def discover_plugins() -> Dict[str, Any]:
    try:
        resp = await async_get(f"{PLUGIN_SANDBOX_URL}/plugins")
        return resp.json() if isinstance(resp, httpx.Response) else {}
    except Exception:
        logger.exception("discover_plugins failed")
        return {}

# register_function may expect a sync callable, so we register sync wrappers that call plugin via sync httpx client
def _make_plugin_tool_sync(plugin_name: str, func_name: str):
    def tool(*args, **kwargs):
        try:
            r = sync_post(f"{PLUGIN_SANDBOX_URL}/execute", json_body={"plugin_name": plugin_name, "function_name": func_name, "args": args, "kwargs": kwargs})
            data = r.json()
            return data.get("result", data)
        except Exception:
            logger.exception("Plugin tool %s.%s failed", plugin_name, func_name)
            return f"Error executing plugin {plugin_name}:{func_name}"
    return tool

async def register_plugins_as_tools(assistant, user_proxy):
    plugins_payload = await discover_plugins()
    # payload format assumed: {"plugin_name": {"function_name": func_spec, ...}, ...}
    if not isinstance(plugins_payload, dict):
        return
    for plugin_name, functions in plugins_payload.items():
        if not isinstance(functions, dict):
            continue
        for func_name, func_spec in functions.items():
            tool_fn = _make_plugin_tool_sync(plugin_name, func_name)
            try:
                register_function(tool_fn, caller=assistant, executor=user_proxy, name=f"{plugin_name}_{func_name}", description=f"{func_spec}")
                logger.info("Registered plugin tool: %s_%s", plugin_name, func_name)
            except Exception:
                logger.exception("Failed to register plugin tool %s.%s", plugin_name, func_name)

# -----------------------
# Git plugin updater (run in background thread)
# -----------------------
def update_plugins_sync():
    try:
        if os.path.exists(PLUGIN_DIR):
            repo = git.Repo(PLUGIN_DIR)
            repo.remotes.origin.pull()
            logger.info("Pulled plugin repo")
        else:
            git.Repo.clone_from(PLUGIN_REPO_URL, PLUGIN_DIR)
            logger.info("Cloned plugin repo")
    except Exception:
        logger.exception("update_plugins_sync failed")

async def update_plugins_loop():
    while True:
        await asyncio.to_thread(update_plugins_sync)
        await asyncio.sleep(3600)  # hourly

# -----------------------
# Redis pubsub listener (async)
# -----------------------
async def listen_for_messages(channel: str, handler):
    try:
        pubsub = aioredis_client.pubsub()
        await pubsub.subscribe(channel)
        logger.info("Subscribed to redis channel %s", channel)
        async for msg in pubsub.listen():
            if not msg:
                continue
            if msg.get("type") == "message":
                raw = msg.get("data")
                try:
                    data = json.loads(raw) if isinstance(raw, (str, bytes)) else raw
                except Exception:
                    data = raw
                # handler might be sync or async
                if asyncio.iscoroutinefunction(handler):
                    await handler(data)
                else:
                    await asyncio.to_thread(handler, data)
    except Exception:
        logger.exception("Redis pubsub listener error - restarting in 5s")
        await asyncio.sleep(5)
        # automatic reconnect loop
        await listen_for_messages(channel, handler)

# -----------------------
# Proactive guidance loop
# -----------------------
async def proactive_guidance_loop():
    while True:
        try:
            docs = await get_relevant_memory("default_user", "Summarize last 2 hours", top_k=1)
            text = " ".join(docs).lower() if docs else ""
            if "travel" in text:
                suggestion = "I noticed you were discussing travel plans. Would you like me to use a flight search plugin?"
                await publish_message("ai_tasks", {"task": "proactive_suggestion", "text": suggestion})
        except Exception:
            logger.exception("proactive_guidance_loop error")
        await asyncio.sleep(3600)

# -----------------------
# Autogen agents & groupchat wiring
# -----------------------
assistant = ConversableAgent("assistant", llm_config={"config_list":[{"model":"llama3"}]}, system_message="You are a helpful assistant.")
mediator = ConversableAgent("mediator", llm_config={"config_list":[{"model":"llama3"}]}, system_message="Resolve conflicts and prioritize tasks.")
user_proxy = ConversableAgent("user_proxy", llm_config={"config_list":[{"model":"llama3"}]}, human_input_mode="NEVER")

groupchat = GroupChat(agents=[user_proxy, assistant, mediator], messages=[], max_round=10, speaker_selection_method="auto")
manager = GroupChatManager(groupchat=groupchat, llm_config={"config_list":[{"model":"llama3"}]})

# -----------------------
# API models & endpoints
# -----------------------
class ChatRequest(BaseModel):
    message: constr(min_length=1, max_length=2000)
    user_id: constr(min_length=1, max_length=100) = "default_user"

class OffloadRequest(BaseModel):
    prompt: constr(min_length=1)

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.post("/offload/")
async def offload_endpoint(req: OffloadRequest):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OpenAI API key not configured")
    try:
        # use OpenAI async if available; openai python lib may provide acreate or similar
        # fall back to running sync call in thread
        try:
            resp = await openai.ChatCompletion.acreate(model="gpt-4o-mini", messages=[{"role":"user","content": req.prompt}])
            content = resp.choices[0].message.content if hasattr(resp, "choices") else str(resp)
        except AttributeError:
            # run sync call in thread
            def _sync_offload():
                return openai.ChatCompletion.create(model="gpt-4o-mini", messages=[{"role":"user","content": req.prompt}])
            resp = await asyncio.to_thread(_sync_offload)
            content = resp.choices[0].message.content if hasattr(resp, "choices") else str(resp)
        return {"response": content}
    except Exception:
        logger.exception("offload failed")
        raise HTTPException(status_code=500, detail="Offload failed")

@app.post("/chat/")
async def chat_endpoint(req: ChatRequest):
    # fetch relevant memory (async)
    memory = await get_relevant_memory(req.user_id, req.message, top_k=5)
    augmented = req.message
    if memory:
        augmented = f"Context:\n{chr(10).join(memory)}\n\nUser: {req.message}"

    # call autogen manager / user_proxy synchronously in thread to avoid blocking
    def _initiate():
        return user_proxy.initiate_chat(manager, message=augmented, clear_history=False, user_id=req.user_id)
    try:
        chat_res = await asyncio.to_thread(_initiate)
    except Exception:
        logger.exception("initiate_chat failed")
        raise HTTPException(status_code=500, detail="Chat failed")

    # defensive extraction of summary/content
    summary = getattr(chat_res, "summary", None)
    if not summary:
        try:
            # some autogen objects have .messages
            summary = chat_res.messages[-1]["content"]
        except Exception:
            summary = str(chat_res)

    # log interaction (async)
    asyncio.create_task(asyncio.to_thread(lambda: None))  # placeholder for non-blocking behavior
    # better: call add to chroma in thread
    if memory_collection:
        asyncio.create_task(asyncio.to_thread(lambda: memory_collection.add(documents=[req.message, summary], metadatas=[{"user": req.user_id}, {"user": req.user_id}], ids=[str(uuid.uuid4()), str(uuid.uuid4())])))

    return {"response": summary}

# -----------------------
# Startup & shutdown
# -----------------------
@app.on_event("startup")
async def startup_event():
    logger.info("Starting autogen core")
    # redis pubsub listener
    asyncio.create_task(listen_for_messages("ai_tasks", handle_incoming_task))
    # plugin updater
    asyncio.create_task(update_plugins_loop())
    # proactive guidance
    asyncio.create_task(proactive_guidance_loop())
    # register plugins (non-blocking)
    asyncio.create_task(register_plugins_as_tools(assistant, user_proxy))
    logger.info("Startup tasks scheduled")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down autogen core")
    try:
        await http_async_client.aclose()
    except Exception:
        pass
    try:
        http_sync_client.close()
    except Exception:
        pass
    try:
        await aioredis_client.close()
    except Exception:
        pass

# -----------------------
# Task handler (example)
# -----------------------
def handle_incoming_task(task_data: Dict[str, Any]):
    logger.info("Received task via redis: %s", task_data)
    # TODO: implement task dispatching logic (e.g., spawn agent runner)
