#!/bin/bash

# Exit immediately if a command exits with a non-zero status.
set -e

# Wait for ChromaDB to be ready
until curl -s ${CHROMA_HOST} > /dev/null; do
  echo "Waiting for ChromaDB service to start..."
  sleep 5
done

# Wait for Ollama to be ready
until curl -s ${OLLAMA_HOST} > /dev/null; do
  echo "Waiting for Ollama service to start..."
  sleep 5
done

# Start the API using uvicorn
exec uvicorn api.main:app --host 0.0.0.0 --port 8008
