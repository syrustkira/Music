#!/bin/bash

# Exit immediately if a command exits with a non-zero status.
set -e

echo "Downloading tinyllama model for Ollama..."

# Wait for the Ollama service to be ready
until curl -s http://ollama:11434 > /dev/null; do
  echo "Waiting for Ollama service to start..."
  sleep 5
done

# Pull the specified model
ollama_host=${OLLAMA_HOST:-http://localhost:11434}
curl -X POST "${ollama_host}/api/pull" -d '{
  "name": "tinyllama"
}'

echo "tinyllama model is now available."
