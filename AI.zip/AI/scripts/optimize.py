import json
import pandas as pd
import logging
import os
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def analyze_performance():
    try:
        with open("performance.log", "r") as f:
            data = [json.loads(line) for line in f]
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logging.error(f"Error reading performance log: {e}")
        return

    df = pd.DataFrame(data)
    if df.empty:
        logging.info("No performance data to analyze.")
        return

    task_avg_duration = df.groupby('task')['duration'].mean().sort_values(ascending=False)
    
    logging.info("\n--- Autonomous Optimization Analysis ---")
    logging.info("Average task durations:")
    logging.info(task_avg_duration)
    
    slow_task_threshold = 10.0
    slow_tasks = task_avg_duration[task_avg_duration > slow_task_threshold]
    
    if not slow_tasks.empty:
        logging.warning("\nBottlenecks detected:")
        for task, avg_time in slow_tasks.items():
            logging.warning(f"Task '{task}' is slow (avg {avg_time:.2f}s). "
                            f"Suggestion: Recommend offloading this task to the cloud or finding a more efficient plugin.")

if __name__ == '__main__':
    analyze_performance()
