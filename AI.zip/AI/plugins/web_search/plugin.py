import sys
import json
import requests

def execute(args: dict) -> str:
    query = args.get("query")
    if not query:
        return "Error: 'query' argument is missing."

    try:
        # This is a placeholder. You'd use a real search API here.
        url = f"https://api.duckduckgo.com/?q={query}&format=json"
        response = requests.get(url)
        response.raise_for_status()
        search_result = response.json().get("AbstractText", "No abstract found.")
        return f"Web search for '{query}': {search_result}"
    except Exception as e:
        return f"Error during web search: {e}"

if __name__ == '__main__':
    args = json.loads(sys.argv[1])
    try:
        result = execute(args)
        print(result)
    except Exception as e:
        print(f"Error executing plugin: {e}", file=sys.stderr)
        sys.exit(1)
