# filename: plugins/example_plugin.py
def get_local_weather(city: str) -> str:
    """A sample plugin function to get local weather."""
    # In a real plugin, this would make a request to a weather API
    return f"The weather in {city} is 